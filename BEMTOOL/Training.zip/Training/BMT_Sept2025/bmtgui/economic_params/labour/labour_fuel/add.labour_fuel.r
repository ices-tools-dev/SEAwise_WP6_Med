# if (printOK) if (printOK) cat('Sourcing file: ', basename('C:/Users/emant/Downloads/stecf_tech_measures-main3/stecf_tech_measures-main/BEMTOOL2.5/code/bmtgui/economic_params/labour/labour_fuel/add.labour_fuel.r'), '\n')
# BEMTOOL - Bio-Economic Model TOOLs - version 2.5
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2018
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.



#
#
#
#
#
#
#
#
#
# ------------------------------------------------------------------------------
# add elements to the list of the p production values
# ------------------------------------------------------------------------------
#
bmt_add.labour_fuel <- function() {
#print("Adding elements to the list...")   
  if (!is.null(bmt_fleet.labour_fuel)) {
  for (r in 1:nrow(bmt_fleet.labour_fuel)) {
  labour_fuel_temp <- as.list(bmt_fleet.labour_fuel[r,]) 
  names(labour_fuel_temp) <-  c(BMT_FLEETSEGMENTS)
  bmt_labour_fuel_list <<- c(bmt_labour_fuel_list, list(labour_fuel_temp)) 
  }
   } else {
   labour_fuel_matrix <- data.frame(matrix(0, nrow=1, ncol=length(BMT_FLEETSEGMENTS)))
   colnames(labour_fuel_matrix) <-  c(BMT_FLEETSEGMENTS)
    # labour_fuel_matrix[1,1] <- c(" fuel costs in labour costs dynamic ")
     if (length(BMT_FLEETSEGMENTS) != 0) {
   for (r in 1:nrow(labour_fuel_matrix)) { 
  labour_fuel_temp <- as.list(labour_fuel_matrix[r,]) 
  bmt_labour_fuel_list <<- c(bmt_labour_fuel_list, list(labour_fuel_temp)) 
  }
  }
 }
#print("labour_fuel (simulation) list successfully updated!", quote=F)
}
