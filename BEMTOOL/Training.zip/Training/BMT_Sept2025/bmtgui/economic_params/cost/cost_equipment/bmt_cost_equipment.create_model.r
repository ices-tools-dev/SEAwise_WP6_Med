# if (printOK) if (printOK) cat('Sourcing file: ', basename('C:/Users/emant/Downloads/stecf_tech_measures-main3/stecf_tech_measures-main/BEMTOOL2.5/code/bmtgui/economic_params/cost/cost_equipment/bmt_cost_equipment.create_model.r'), '\n')
# BEMTOOL - Bio-Economic Model TOOLs - version 2.5
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2018
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.



#
#
#
#
#
#
#
#
#
#
# ------------------------------------------------------------------------------
# create model for the tree of p production
# ------------------------------------------------------------------------------
#
bmt_cost_equipment.create_model <- function() {
#print("Creating model...")   
  # create list store
  bmt_cost_equipment.model <<- gtkListStoreNew("gchararray",  rep("gdouble", length(BMT_YEARS_FORECAST)), "gboolean")  
  bmt_add.cost_equipment()
  # add items
  if (length(bmt_cost_equipment_list) != 0) { 
  for (i in 1:length(bmt_cost_equipment_list)) {
    iter <- bmt_cost_equipment.model$append()$iter
   #print(paste("in sexratios.model:", as.character(sexratios[[i]]$month)))
    bmt_cost_equipment.model$set(iter,0, bmt_cost_equipment_list[[i]][1])
    for (e in 1:length(BMT_YEARS_FORECAST)) {
   # print(paste("in model:", years[nc]) )
         bmt_cost_equipment.model$set(iter, e, as.numeric(bmt_cost_equipment_list[[i]][e+1]))
    }
       bmt_cost_equipment.model$set(iter, (length(BMT_YEARS_FORECAST)+1),TRUE)
  } 
  }
  #print("cost_equipment Model successfully created!")  
}
