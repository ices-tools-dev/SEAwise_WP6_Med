# if (printOK) if (printOK) cat('Sourcing file: ', basename('C:/Users/emant/Downloads/stecf_tech_measures-main3/stecf_tech_measures-main/BEMTOOL2.5/code/bmtgui/economic_params/price/price_elast_import/add.price_elast_import.r'), '\n')
# BEMTOOL - Bio-Economic Model TOOLs - version 2.5
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2018
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.



#
#
#
#
#
#
#
#
#
# ------------------------------------------------------------------------------
# add elements to the list of the p production values
# ------------------------------------------------------------------------------
#
bmt_add.price_elast_import <- function() {
#print("Adding elements to the list...")   
  if (!is.null(bmt_fleet.price_elast_import)) {
  for (r in 1:nrow(bmt_fleet.price_elast_import)) {
  price_elast_import_temp <- as.list(bmt_fleet.price_elast_import[r,]) 
  names(price_elast_import_temp) <-  c("Species",BMT_FLEETSEGMENTS)
  bmt_price_elast_import_list <<- c(bmt_price_elast_import_list, list(price_elast_import_temp)) 
  }
   } else {
   price_elast_import_matrix <- data.frame(matrix(0, nrow=length(BMT_SPECIES), ncol=(length(BMT_FLEETSEGMENTS)+1)))
   colnames(price_elast_import_matrix) <-  c("Species",BMT_FLEETSEGMENTS)
     price_elast_import_matrix$Species <- BMT_SPECIES
     if (length(BMT_SPECIES) != 0) {
   for (r in 1:nrow(price_elast_import_matrix)) { 
  price_elast_import_temp <- as.list(price_elast_import_matrix[r,]) 
  bmt_price_elast_import_list <<- c(bmt_price_elast_import_list, list(price_elast_import_temp)) 
  }
  }
 }
#print("price_elast_import (simulation) list successfully updated!", quote=F)
}
