# if (printOK) if (printOK) cat('Sourcing file: ', basename('C:/Users/emant/Downloads/stecf_tech_measures-main3/stecf_tech_measures-main/BEMTOOL2.5/code/bmtgui/economic_params/price/price_importweight/price_importweight.cell_edited.r'), '\n')
# BEMTOOL - Bio-Economic Model TOOLs - version 2.5
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2018
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.



#
#
#
#
#
#
#
#
#
# ------------------------------------------------------------------------------
# Function for the editing of the cells
# ------------------------------------------------------------------------------
#
bmt_price_importweight.cell_edited <- function(cell, path.string, new.text, data) {
  #checkPtrType(data, "price_importweightkListStore")
  if (is.na(as.double(new.text) )) {
      showError("Value of coefficient for price functions must be numbers!")
 } else {
 bmt_price_importweight.model <- data 
  path <- gtkTreePathNewFromString(path.string)
  print(paste("price_importweight Edited row:", (as.numeric(path.string)+1)))
  column <- as.integer(cell$getData("column"))
  print(paste("price_importweight Edited column:", column))
  iter <- bmt_price_importweight.model$getIter(path)$iter
   #print(paste("new text:", new.text))
  	i <- path$getIndices()[[1]]+1
  	#print(paste("indice i:", i))
  #	print(pproductions[[i]])
  	bmt_price_importweight_list[[i]][column+1] <<- as.double(new.text)           # [column+1]
  #	print(paste("indice column:", column+1))
  #	print(pproductions[[i]][column+1])
  	bmt_price_importweight.model$set(iter, column, bmt_price_importweight_list[[i]][column+1])

         for (r in 1:length(bmt_price_importweight_list)) {
  bmt_fleet.price_importweight[r,] <<- as.double(as.character(bmt_price_importweight_list[[r]]))
  }

   # elasti <- c()
for (nco in 2:ncol( bmt_fleet.price_importweight)) {
   # elasti <- c(elasti, bmt_fleet.price_importweight[,nco])
    mat_cfg_price[(length(BMT_SPECIES)*length(BMT_FLEETSEGMENTS)+5):(length(BMT_SPECIES)*length(BMT_FLEETSEGMENTS)+4+length(BMT_SPECIES)),nco] <<-  bmt_fleet.price_importweight[,nco]
}

selected <- gtkComboBoxGetActiveText(bmt_combo_price_models)
mat_cfg_price[2,2] <<- which(PRICE_MODELS$option_name == selected)

print(mat_cfg_price)


}
}
